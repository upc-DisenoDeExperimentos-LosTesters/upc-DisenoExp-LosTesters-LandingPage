import 'package:flutter/material.dart';

import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/carrier/reports/reports_carrier_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/carrier/shipments/shipments_screen2.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/carrier/vehicle/vehicle_detail_carrier_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/carrier/profile/profile_screen2.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/login_screen.dart';


class NewReportScreen extends StatefulWidget {
  final String name;
  final String lastName;

  const NewReportScreen({
    Key? key,
    required this.name,
    required this.lastName,
  }) : super(key: key);

  @override
  _NewReportScreenState createState() => _NewReportScreenState();
}

class _NewReportScreenState extends State<NewReportScreen> {
  String? _selectedReportType;
  final TextEditingController _descriptionController = TextEditingController();
  final List<String> _reportTypes = ['Tipo A', 'Tipo B', 'Tipo C'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C2F38),
        title: Text(' ${widget.name} ${widget.lastName} ROL Transportista', style: const TextStyle(color: Colors.white)),

        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () {
              Scaffold.of(context).openDrawer(); // Usa el context correcto para abrir el drawer
            },
          ),
        ),
      ),
      backgroundColor: const Color(0xFF2C2F38),

      // Aquí se define el sidebar (drawer)
      drawer: Drawer(
        backgroundColor: const Color(0xFF2C2F38), // Cambia el color de fondo del Drawer
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: const Color(0xFF2C2F38), // Cambia también el fondo del DrawerHeader si es necesario
              ),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/login_logo.png', // Reemplaza con la ruta correcta del logo
                    height: 100,
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.person, color: Colors.white), // Cambia el color de los íconos si es necesario
              title: Text('PERFIL', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfileScreen2(name: widget.name, lastName: widget.lastName),
                  ),
                );              },
            ),
            ListTile(
              leading: Icon(Icons.report, color: Colors.white),
              title: Text('REPORTES', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReportsCarrierScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.directions_car, color: Colors.white),
              title: const Text('VEHICULOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VehicleDetailCarrierScreenScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.local_shipping, color: Colors.white),
              title: Text('ENVIOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ShipmentsScreen2(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            const SizedBox(height: 160),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.white),
              title: const Text('CERRAR SESIÓN', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginScreen(
                      onLoginClicked: (username, password) {
                        print('Usuario: $username, Contraseña: $password');
                      },
                      onRegisterClicked: () {
                        print('Registrarse');
                      },
                    ),
                  ),
                      (Route<dynamic> route) => false, // Cerrar todas las rutas anteriores y navegar solo a LoginScreen
                );
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const CircleAvatar(
                      radius: 30,
                      child: Icon(Icons.person, size: 30),
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: 'Tipo de Reporte',
                        border: OutlineInputBorder(),
                      ),
                      value: _selectedReportType,
                      items: _reportTypes.map((String type) {
                        return DropdownMenuItem<String>(
                          value: type,
                          child: Text(type),
                        );
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          _selectedReportType = newValue;
                        });
                      },
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _descriptionController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Descripción:',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFA000),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: _createReport,
                child: const Text(
                  'Crear Nuevo Reporte',
                  style: TextStyle(color: Colors.black),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _createReport() {
    final reportType = _selectedReportType;
    final description = _descriptionController.text;

    if (reportType != null && description.isNotEmpty) {
      // Crear el reporte en formato Map
      final newReport = {
        'name': 'Nombre del Reporte',
        'type': reportType,
        'description': description,
      };

      // Retornar el nuevo reporte a la pantalla anterior
      Navigator.pop(context, newReport);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, completa todos los campos')),
      );
    }
  }
}
