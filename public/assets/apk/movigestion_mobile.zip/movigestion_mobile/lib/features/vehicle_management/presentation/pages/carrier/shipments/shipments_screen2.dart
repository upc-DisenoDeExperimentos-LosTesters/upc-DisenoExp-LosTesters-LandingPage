import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart'; // Para formatear la fecha

import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/carrier/reports/reports_carrier_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/carrier/vehicle/vehicle_detail_carrier_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/carrier/profile/profile_screen2.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/login_screen.dart';

class ShipmentsScreen2 extends StatefulWidget {
  final String name;
  final String lastName;

  const ShipmentsScreen2({
    Key? key,
    required this.name,
    required this.lastName,
  }) : super(key: key);

  @override
  _ShipmentsScreen2State createState() => _ShipmentsScreen2State();
}

class _ShipmentsScreen2State extends State<ShipmentsScreen2> {
  List<Map<String, dynamic>> _shipments = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchShipments();
  }

  Future<void> _fetchShipments() async {
    try {
      // Obtener los perfiles para verificar el nombre del conductor
      final profilesResponse = await http.get(Uri.parse('https://app-241107014459.azurewebsites.net/api/profiles'));

      if (profilesResponse.statusCode == 200) {
        List<dynamic> profiles = json.decode(profilesResponse.body);
        bool isDriverExists = profiles.any((profile) => profile['name'] == widget.name);

        if (isDriverExists) {
          // Obtener los envíos si el conductor existe
          final shipmentsResponse = await http.get(Uri.parse('https://app-241107014459.azurewebsites.net/api/shipments'));

          if (shipmentsResponse.statusCode == 200) {
            List<dynamic> data = json.decode(shipmentsResponse.body);
            setState(() {
              _shipments = data
                  .where((shipment) => shipment['driverName'] == widget.name)
                  .map((shipment) => {
                'destiny': shipment['destiny'],
                'description': shipment['description'],
                'createdAt': DateTime.parse(shipment['createdAt']),
              })
                  .toList();
            });
          } else {
            print('Error al cargar envíos: ${shipmentsResponse.statusCode}');
          }
        } else {
          print('El conductor no existe.');
        }
      } else {
        print('Error al cargar perfiles: ${profilesResponse.statusCode}');
      }
    } catch (e) {
      print('Error al obtener los envíos: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF607D8B),
        title: Text(' ${widget.name} ${widget.lastName} ROL Transportista ENVIOS', style: const TextStyle(color: Colors.white)),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
      ),
      backgroundColor: const Color(0xFF607D8B),
      drawer: Drawer(
        backgroundColor: const Color(0xFF2C2F38),
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: const Color(0xFF2C2F38),
              ),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/login_logo.png',
                    height: 100,
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.person, color: Colors.white),
              title: Text('PERFIL', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfileScreen2(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.report, color: Colors.white),
              title: Text('REPORTES', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReportsCarrierScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.directions_car, color: Colors.white),
              title: const Text('VEHICULOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VehicleDetailCarrierScreenScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.local_shipping, color: Colors.white),
              title: Text('ENVIOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ShipmentsScreen2(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            const SizedBox(height: 160),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.white),
              title: const Text('CERRAR SESIÓN', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginScreen(
                      onLoginClicked: (username, password) {
                        print('Usuario: $username, Contraseña: $password');
                      },
                      onRegisterClicked: () {
                        print('Registrarse');
                      },
                    ),
                  ),
                      (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _shipments.isEmpty
          ? Center(child: Text('No hay envíos disponibles'))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: _shipments.length,
          itemBuilder: (context, index) {
            return _buildShipmentCard(
              _shipments[index]['destiny'],
              _shipments[index]['description'],
              _shipments[index]['createdAt'],
            );
          },
        ),
      ),
    );
  }

  Widget _buildShipmentCard(String destiny, String description, DateTime createdAt) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      margin: const EdgeInsets.only(bottom: 16.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            const CircleAvatar(
              radius: 30,
              child: Icon(Icons.local_shipping, size: 30),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Destino: $destiny', style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('Descripción: $description'),
                  Text('Fecha: ${DateFormat.yMMMd().format(createdAt)}'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
