import 'package:flutter/material.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/user_registration_screen.dart';

class RegisterScreen extends StatefulWidget {
  final VoidCallback onNextClicked;

  const RegisterScreen({Key? key, required this.onNextClicked}) : super(key: key);

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  String _selectedRole = ''; // Variable para almacenar el rol seleccionado

  void _onRoleSelected(String role) {
    setState(() {
      _selectedRole = role;
    });
  }

  void _navigateToUserRegistration() {
    if (_selectedRole.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => UserRegistrationScreen(
            selectedRole: _selectedRole,
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor selecciona un rol')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2C2F38), // Fondo oscuro
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 40),
            Image.asset(
              'assets/images/login_logo.png', // Asegúrate de tener este archivo en tus assets
              height: 100,
            ),
            const SizedBox(height: 40),
            _buildRoleButton('Gerente'),
            const SizedBox(height: 16),
            _buildRoleButton('Transportista'),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _navigateToUserRegistration,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFA000), // Color del botón "Siguiente"
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: const Text(
                'Siguiente',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoleButton(String role) {
    return ElevatedButton(
      onPressed: () => _onRoleSelected(role),
      style: ElevatedButton.styleFrom(
        backgroundColor: _selectedRole == role ? Colors.orange : Colors.white,
        foregroundColor: Colors.black,
        minimumSize: const Size(double.infinity, 50),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
      ),
      child: Text(
        role.toUpperCase(),
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
    );
  }
}
