import 'package:flutter/material.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/vehicle/assign_vehicle_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/vehicle/vehicle_detail_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/profile/profile_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/shipments/shipments_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/reports/reports_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/login_screen.dart';


class VehiclesScreen extends StatefulWidget {
  final String name;
  final String lastName;

  const VehiclesScreen({
    Key? key,
    required this.name,
    required this.lastName,
  }) : super(key: key);

  @override
  _VehiclesScreenState createState() => _VehiclesScreenState();
}

class _VehiclesScreenState extends State<VehiclesScreen> {
  final List<Map<String, String>> vehicles = [
    {'modelo': 'Toyota Hilux', 'placa': 'XYZ123', 'asignado': 'Juan Pérez'},
    {'modelo': 'Nissan Frontier', 'placa': 'ABC456', 'asignado': 'María García'},
  ];

  // Método para agregar vehículo a la lista
  void _addVehicle(Map<String, String> newVehicle) {
    setState(() {
      vehicles.add(newVehicle);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C2F38),
        title: Text(' ${widget.name} ${widget.lastName} ROL Empresario', style: const TextStyle(color: Colors.white)),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () {
              Scaffold.of(context).openDrawer(); // Usa el context correcto para abrir el drawer
            },
          ),
        ),
      ),
      backgroundColor: const Color(0xFF2C2F38),

      // Aquí se define el sidebar (drawer)
      drawer: Drawer(
        backgroundColor: const Color(0xFF2C2F38),
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Color(0xFF2C2F38),
              ),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/login_logo.png',
                    height: 100,
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person, color: Colors.white),
              title: const Text('PERFIL', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfileScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.report, color: Colors.white),
              title: const Text('REPORTES', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReportsScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.directions_car, color: Colors.white),
              title: const Text('VEHICULOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VehiclesScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.local_shipping, color: Colors.white),
              title: const Text('ENVIOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ShipmentsScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            const SizedBox(height: 160),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.white),
              title: const Text('CERRAR SESIÓN', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginScreen(
                      onLoginClicked: (username, password) {
                        print('Usuario: $username, Contraseña: $password');
                      },
                      onRegisterClicked: () {
                        print('Registrarse');
                      },
                    ),
                  ),
                      (Route<dynamic> route) => false, // Cerrar todas las rutas anteriores y navegar solo a LoginScreen
                );
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Lista de vehículos
            Expanded(
              child: ListView.builder(
                itemCount: vehicles.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      // Navegar a la pantalla de detalle
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => VehicleDetailScreen(
                            modelo: vehicles[index]['modelo']!,
                            placa: vehicles[index]['placa']!,
                            conductor: vehicles[index]['asignado']!,
                            name: widget.name, // Pasa el parámetro name
                            lastName: widget.lastName, // Pasa el parámetro lastName
                          ),
                        ),
                      );

                    },
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Row(
                          children: [
                            const Icon(Icons.directions_car, size: 40),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Modelo: ${vehicles[index]['modelo']}',
                                      style: const TextStyle(fontWeight: FontWeight.bold)),
                                  Text('Placa: ${vehicles[index]['placa']}'),
                                  Text('Asignado a: ${vehicles[index]['asignado']}'),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            // Botón para agregar un nuevo vehículo
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AssignVehicleScreen(
                      onVehicleAdded: _addVehicle,
                      name: widget.name, // Pasa el parámetro name
                      lastName: widget.lastName, // Pasa el parámetro lastName
                    ),
                  ),
                );

              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFA000),
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: const Text(
                'Asignar nuevo Vehículo',
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
