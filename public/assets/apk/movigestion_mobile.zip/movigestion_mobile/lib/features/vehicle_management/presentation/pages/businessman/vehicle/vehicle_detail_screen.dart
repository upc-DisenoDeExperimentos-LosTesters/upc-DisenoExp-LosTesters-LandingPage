import 'package:flutter/material.dart';

import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/profile/profile_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/shipments/shipments_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/vehicle/vehicles_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/reports/reports_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/login_screen.dart';



class VehicleDetailScreen extends StatelessWidget {
  final String modelo;
  final String placa;
  final String conductor;
  final String name;
  final String lastName;

  const VehicleDetailScreen({
    Key? key,
    required this.modelo,
    required this.placa,
    required this.conductor,
    required this.name,
    required this.lastName,
  }) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalle del Vehículo'),
        backgroundColor: const Color(0xFF2C2F38),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () {
              Scaffold.of(context).openDrawer(); // Usa el context correcto para abrir el drawer
            },
          ),
        ),
      ),
      backgroundColor: const Color(0xFF2C2F38),

      // Aquí se define el sidebar (drawer)
      drawer: Drawer(
        backgroundColor: const Color(0xFF2C2F38), // Cambia el color de fondo del Drawer
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: const Color(0xFF2C2F38), // Cambia también el fondo del DrawerHeader si es necesario
              ),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/login_logo.png', // Reemplaza con la ruta correcta del logo
                    height: 100,
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.person, color: Colors.white),
              title: Text('PERFIL', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProfileScreen(name: name, lastName: lastName)), // Usa name y lastName directamente
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.report, color: Colors.white),
              title: Text('REPORTES', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReportsScreen(name: name, lastName: lastName), // Usa name y lastName directamente
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.directions_car, color: Colors.white),
              title: Text('VEHICULOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VehiclesScreen(name: name, lastName: lastName), // Usa name y lastName directamente
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.local_shipping, color: Colors.white),
              title: Text('ENVIOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ShipmentsScreen(name: name, lastName: lastName), // Usa name y lastName directamente
                  ),
                );
              },
            ),
            const SizedBox(height: 160),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.white),
              title: const Text('CERRAR SESIÓN', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginScreen(
                      onLoginClicked: (username, password) {
                        print('Usuario: $username, Contraseña: $password');
                      },
                      onRegisterClicked: () {
                        print('Registrarse');
                      },
                    ),
                  ),
                      (Route<dynamic> route) => false, // Cerrar todas las rutas anteriores y navegar solo a LoginScreen
                );
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Imagen y datos del vehículo
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset(
                      'assets/images/vehiculo_image.png', // Ruta de la imagen del vehículo
                      height: 150,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Placa: $placa',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text('Conductor: $conductor'),
                  const SizedBox(height: 5),
                  const Text(
                    'Estado: Óptimo',
                    style: TextStyle(color: Colors.green),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Detalle del estado
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Detalle del Estado',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Filas de optimización
                  _buildOptimizationRow('Motor', '80% / 100%'),
                  const SizedBox(height: 10),
                  _buildOptimizationRow('Combustible', '90% / 100%'),
                  const SizedBox(height: 10),
                  _buildOptimizationRow('Neumáticos', '90% / 100%'),
                  const SizedBox(height: 10),
                  _buildOptimizationRow('Sistema Eléctrico', '80% / 100%'),
                  const SizedBox(height: 10),
                  _buildOptimizationRow('Temperatura de Transmisión', '80% / 100%'),
                  const SizedBox(height: 20),
                  // Calificación del vehículo
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Calificación'),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'Óptimo',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Botón para contactar con el área de mantenimiento
            ElevatedButton.icon(
              onPressed: () {
                // Acción para contactar con el área de mantenimiento
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFA000),
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              icon: const Icon(Icons.call, color: Colors.black),
              label: const Text(
                'Comunicarse con área de Mantenimiento',
                style: TextStyle(color: Colors.black),
              ),
            ),
            const SizedBox(height: 20),

            // Próximas fechas de mantenimiento
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Row(
                children: const [
                  Icon(Icons.calendar_today, size: 40),
                  SizedBox(width: 10),
                  Text(
                    'Próximas fechas de mantenimiento',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Método para generar las filas de optimización
  Widget _buildOptimizationRow(String resource, String optimization) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(resource),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(optimization),
        ),
      ],
    );
  }
}
