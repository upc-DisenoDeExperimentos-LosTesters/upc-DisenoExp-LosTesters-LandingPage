import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:movigestion_mobile/core/app_constants.dart';
import 'package:movigestion_mobile/features/vehicle_management/data/remote/profile_service.dart';
import 'package:movigestion_mobile/features/vehicle_management/data/remote/profile_model.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/shipments/shipments_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/profile/profile_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/vehicle/vehicles_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/reports/reports_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/login_screen.dart';


class AssignShipmentScreen extends StatefulWidget {
  final String name;
  final String lastName;

  const AssignShipmentScreen({
    Key? key,
    required this.name,
    required this.lastName,
  }) : super(key: key);

  @override
  _AssignShipmentScreenState createState() => _AssignShipmentScreenState();
}

class _AssignShipmentScreenState extends State<AssignShipmentScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController driverController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController statusController = TextEditingController();

  Future<bool> _verifyDriver(String name) async {
    final url = Uri.parse('${AppConstants.baseUrl}${AppConstants.profile}');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        List<dynamic> profiles = json.decode(response.body);
        for (var profileJson in profiles) {
          ProfileModel profile = ProfileModel.fromJson(profileJson);
          if (profile.name == name && profile.type == 'Transportista') {
            return true; // El conductor es válido
          }
        }
      } else {
        print('Error al obtener los perfiles: ${response.statusCode}');
      }
    } catch (e) {
      print('Error al verificar el conductor: $e');
    }
    return false; // El conductor no es válido o no se encontró
  }

  Future<void> _submitShipment() async {
    if (await _verifyDriver(driverController.text)) {
      final url = Uri.parse('${AppConstants.baseUrl}${AppConstants.shipment}');
      final body = {
        "destiny": addressController.text,
        "description": descriptionController.text,
        "driverName": driverController.text,
        "status": statusController.text,
      };

      try {
        final response = await http.post(
          url,
          headers: {'Content-Type': 'application/json'},
          body: json.encode(body),
        );

        if (response.statusCode == 200 || response.statusCode == 201) {
          // Envío asignado exitosamente
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Envío asignado exitosamente')),
          );

          // Limpiar los campos
          driverController.clear();
          addressController.clear();
          descriptionController.clear();
          statusController.clear();
        } else {
          // Error al asignar el envío
          print('Error al asignar envío: ${response.statusCode}');
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Error al asignar envío')),
          );
        }
      } catch (e) {
        print('Error al realizar la solicitud: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Error al realizar la solicitud')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Conductor no válido o no es Transportista')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C2F38),
        title: Text(' ${widget.name} ${widget.lastName} ROL Empresario', style: const TextStyle(color: Colors.white)),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
      ),
      backgroundColor: const Color(0xFF2C2F38),
      drawer: Drawer(
        backgroundColor: const Color(0xFF2C2F38),
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: const BoxDecoration(color: Color(0xFF2C2F38)),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/login_logo.png',
                    height: 100,
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person, color: Colors.white),
              title: const Text('PERFIL', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfileScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.report, color: Colors.white),
              title: const Text('REPORTES', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReportsScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.directions_car, color: Colors.white),
              title: const Text('VEHICULOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VehiclesScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.local_shipping, color: Colors.white),
              title: const Text('ENVIOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ShipmentsScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            const SizedBox(height: 160),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.white),
              title: const Text('CERRAR SESIÓN', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginScreen(
                      onLoginClicked: (username, password) {
                        print('Usuario: $username, Contraseña: $password');
                      },
                      onRegisterClicked: () {
                        print('Registrarse');
                      },
                    ),
                  ),
                      (Route<dynamic> route) => false, // Cerrar todas las rutas anteriores y navegar solo a LoginScreen
                );
              },
            ),
          ],
        ),

      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              TextFormField(
                controller: driverController,
                decoration: InputDecoration(
                  labelText: 'Nombre conductor asignado',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese el nombre del conductor';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: addressController,
                decoration: InputDecoration(
                  labelText: 'Dirección',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese la dirección';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: descriptionController,
                decoration: InputDecoration(
                  labelText: 'Descripción del tipo de envío',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese la descripción del envío';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: statusController,
                decoration: InputDecoration(
                  labelText: 'Estado',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese el estado del envío';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _submitShipment();
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFA000),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  minimumSize: const Size(double.infinity, 50),
                ),
                child: const Text(
                  'Asignar envío',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
