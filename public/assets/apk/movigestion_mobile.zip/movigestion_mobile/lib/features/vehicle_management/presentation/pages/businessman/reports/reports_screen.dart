import 'package:flutter/material.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/profile/profile_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/shipments/shipments_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/vehicle/vehicles_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/login_screen.dart';


class ReportsScreen extends StatelessWidget {
  final String name;
  final String lastName;

  const ReportsScreen({
    Key? key,
    required this.name,
    required this.lastName,
  }) : super(key: key);

  // Lista de reportes constante
  final List<Map<String, String>> reports = const [
    {'name': 'Reporte 1', 'tipo': 'Mantenimiento', 'descripcion': 'Lorem ipsum dolor sit amet'},
    {'name': 'Reporte 2', 'tipo': 'Incidente', 'descripcion': 'Consectetur adipiscing elit'},
    {'name': 'Reporte 3', 'tipo': 'Mantenimiento', 'descripcion': 'Sed do eiusmod tempor'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C2F38),
        title: Text(' $name $lastName ROL Empresario', style: const TextStyle(color: Colors.white)),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () {
              Scaffold.of(context).openDrawer(); // Usa el context correcto para abrir el drawer
            },
          ),
        ),
      ),
      backgroundColor: const Color(0xFF2C2F38), // Fondo similar al estilo general

      drawer: Drawer(
        backgroundColor: const Color(0xFF2C2F38), // Cambia el color de fondo del Drawer
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Color(0xFF2C2F38),
              ),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/login_logo.png', // Reemplaza con la ruta correcta del logo
                    height: 100,
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person, color: Colors.white),
              title: const Text('PERFIL', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfileScreen(name: name, lastName: lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.report, color: Colors.white),
              title: const Text('REPORTES', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReportsScreen(name: name, lastName: lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.directions_car, color: Colors.white),
              title: const Text('VEHICULOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VehiclesScreen(name: name, lastName: lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.local_shipping, color: Colors.white),
              title: const Text('ENVIOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ShipmentsScreen(name: name, lastName: lastName),
                  ),
                );
              },
            ),
            const SizedBox(height: 160),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.white),
              title: const Text('CERRAR SESIÓN', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginScreen(
                      onLoginClicked: (username, password) {
                        print('Usuario: $username, Contraseña: $password');
                      },
                      onRegisterClicked: () {
                        print('Registrarse');
                      },
                    ),
                  ),
                      (Route<dynamic> route) => false, // Cerrar todas las rutas anteriores y navegar solo a LoginScreen
                );
              },
            ),
          ],
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Lista de reportes
            Expanded(
              child: ListView.builder(
                itemCount: reports.length,
                itemBuilder: (context, index) {
                  return _buildReportCard(
                    reports[index]['name']!,
                    reports[index]['tipo']!,
                    reports[index]['descripcion']!,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Método para construir cada tarjeta de reporte
  Widget _buildReportCard(String name, String tipo, String descripcion) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            const CircleAvatar(
              radius: 30,
              child: Icon(Icons.person, size: 30),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Name: $name', style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('Tipo: $tipo'),
                  Text('Descripcion: $descripcion'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
