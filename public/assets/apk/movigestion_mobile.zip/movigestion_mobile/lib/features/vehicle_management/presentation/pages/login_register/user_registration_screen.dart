import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:movigestion_mobile/core/app_constants.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/profile/profile_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/carrier/profile/profile_screen2.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/login_screen.dart';

class UserRegistrationScreen extends StatefulWidget {
  final String selectedRole;

  const UserRegistrationScreen({
    Key? key,
    required this.selectedRole,
  }) : super(key: key);

  @override
  _UserRegistrationScreenState createState() => _UserRegistrationScreenState();
}

class _UserRegistrationScreenState extends State<UserRegistrationScreen> {
  final _nameController = TextEditingController();
  final _usernameController = TextEditingController();
  final _dniController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  bool _termsAccepted = false;
  bool _formValid = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _nameController.addListener(_validateForm);
    _usernameController.addListener(_validateForm);
    _dniController.addListener(_validateForm);
    _passwordController.addListener(_validateForm);
    _confirmPasswordController.addListener(_validateForm);
  }

  void _validateForm() {
    setState(() {
      if (_nameController.text.isEmpty ||
          _usernameController.text.isEmpty ||
          _dniController.text.isEmpty ||
          _passwordController.text.isEmpty ||
          _confirmPasswordController.text.isEmpty) {
        _errorMessage = 'Todos los campos son obligatorios';
        _formValid = false;
      } else if (_passwordController.text != _confirmPasswordController.text) {
        _errorMessage = 'Las contraseñas no coinciden';
        _formValid = false;
      } else if (!_termsAccepted) {
        _errorMessage = 'Debes aceptar los Términos y Condiciones';
        _formValid = false;
      } else {
        _errorMessage = ''; // Sin errores
        _formValid = true;
      }
    });
  }

  Future<void> _submitRegistrationForm() async {
    final url = Uri.parse('${AppConstants.baseUrl}${AppConstants.profile}');

    final body = {
      "name": _nameController.text,
      "lastName": _usernameController.text,
      "email": _dniController.text,
      "password": _passwordController.text,
      "type": widget.selectedRole,
    };

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode(body),
      );

      if (response.statusCode == 201 || response.statusCode == 200) {
        // Registro exitoso
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Registro exitoso')),
        );
        _navigateBasedOnRole();
      } else {
        // Error al registrar
        setState(() {
          _errorMessage = 'Error al registrar usuario: ${response.statusCode}';
        });
        print('Error al registrar usuario: ${response.body}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error al realizar la solicitud';
      });
      print('Error al realizar la solicitud: $e');
    }
  }

  void _navigateBasedOnRole() {
    // Redirigir según el rol seleccionado
    if (widget.selectedRole == 'Gerente') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ProfileScreen(
            name: _nameController.text, // Pasar el valor del nombre
            lastName: _usernameController.text, // Pasar el valor del apellido
          ),
        ),
      );
    } else if (widget.selectedRole == 'Transportista') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ProfileScreen(
            name: _nameController.text, // Pasar el valor del nombre
            lastName: _usernameController.text, // Pasar el valor del apellido
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2C2F3A), // Fondo oscuro
      body: SingleChildScrollView( // Permitir que el contenido sea desplazable
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 40),

              // Logo en la parte superior
              Image.asset(
                'assets/images/login_logo.png',
                height: 100,
              ),
              const SizedBox(height: 40),

              // Título basado en el rol seleccionado
              Text(
                'Registro de ${widget.selectedRole}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),

              // Campo Nombre
              TextField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Nombre',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              const SizedBox(height: 20),

              // Campo Apellido
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(
                  labelText: 'Apellido',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              const SizedBox(height: 20),

              // Campo Correo
              TextField(
                controller: _dniController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              const SizedBox(height: 20),

              // Campo Contraseña
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Contraseña',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              const SizedBox(height: 20),

              // Campo Confirmar Contraseña
              TextField(
                controller: _confirmPasswordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Confirmar Contraseña',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              const SizedBox(height: 20),

              // Checkbox de Términos y Condiciones
              Row(
                children: [
                  Checkbox(
                    value: _termsAccepted,
                    onChanged: (bool? newValue) {
                      setState(() {
                        _termsAccepted = newValue ?? false;
                        _validateForm();
                      });
                    },
                  ),
                  const Text(
                    'Confirmar Términos y Condiciones',
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Mensaje de error en rojo
              if (_errorMessage.isNotEmpty)
                Text(
                  _errorMessage,
                  style: const TextStyle(color: Colors.red),
                ),

              const SizedBox(height: 20),

              // Botón "EMPEZAR" (habilitado solo si el formulario es válido)
              ElevatedButton(
                onPressed: _formValid ? _submitRegistrationForm : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _formValid ? const Color(0xFFFFA000) : Colors.grey, // Color dinámico
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  minimumSize: const Size(double.infinity, 50), // Ancho completo
                ),
                child: const Text(
                  'EMPEZAR',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Botón "¿Ya eres usuario? - Inicia Sesión"
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => LoginScreen(
                        onLoginClicked: (username, password) {
                          // Aquí puedes manejar la lógica cuando el usuario inicie sesión
                          print('Usuario: $username, Contraseña: $password');
                        },
                        onRegisterClicked: () {
                          // Aquí puedes manejar la lógica cuando el usuario quiera registrarse
                          print('Registrarse');
                        },
                      ),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent, // Fondo transparente
                  elevation: 0, // Sin sombra
                ),
                child: const Text(
                  '¿Ya eres usuario? - Inicia Sesión',
                  style: TextStyle(
                    color: Colors.white,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
