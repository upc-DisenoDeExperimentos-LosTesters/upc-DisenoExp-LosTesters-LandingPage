import 'package:flutter/material.dart';
import 'package:movigestion_mobile/features/vehicle_management/data/remote/profile_service.dart';
import 'package:movigestion_mobile/features/vehicle_management/data/repository/profile_repository.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/register_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/profile/profile_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/carrier/profile/profile_screen2.dart';
import 'package:movigestion_mobile/features/vehicle_management/data/remote/profile_model.dart';

class LoginScreen extends StatelessWidget {
  final Function(String, String) onLoginClicked;
  final VoidCallback onRegisterClicked;

  const LoginScreen({
    Key? key,
    required this.onLoginClicked,
    required this.onRegisterClicked,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final usernameController = TextEditingController();
    final passwordController = TextEditingController();
    final profileRepository = ProfileRepository(profileService: ProfileService());

    return Scaffold(
      backgroundColor: const Color(0xFF2C2F38),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset('assets/images/login_logo.png', height: 100),
            const SizedBox(height: 40),
            TextField(
              controller: usernameController,
              decoration: InputDecoration(
                hintText: 'Usuario (Email)',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Contraseña',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                if (usernameController.text.isNotEmpty && passwordController.text.isNotEmpty) {
                  try {
                    // Realizar la solicitud a la API con el email y la contraseña
                    final profile = await profileRepository.getProfileByEmailAndPassword(
                      usernameController.text,
                      passwordController.text,
                    );

                    // Verificar si el perfil es válido (es decir, si la respuesta no es nula)
                    if (profile != null && profile.email == usernameController.text) {
                      // Verificar el tipo de perfil y redirigir según el rol, pasando el nombre y apellido
                      if (profile.type == 'Gerente') {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ProfileScreen(
                              name: profile.name,
                              lastName: profile.lastName,
                            ),

                          ),
                        );
                      } else if (profile.type == 'Transportista') {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ProfileScreen2(
                              name: profile.name,
                              lastName: profile.lastName,
                            ),
                          ),
                        );
                      }
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Inicio de sesión exitoso')),
                      );
                    } else {
                      // Si no coincide, mostrar un mensaje de error
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Usuario o contraseña incorrecta')),
                      );
                    }
                  } catch (e) {
                    // Capturar cualquier error que ocurra al obtener los perfiles
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Error al obtener los perfiles')),
                    );
                    print('Error al obtener perfil: $e');
                  }
                } else {
                  // Si no se ingresan usuario o contraseña
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Por favor ingrese usuario y contraseña')),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFA000),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                minimumSize: const Size(double.infinity, 50),
              ),
              child: const Text(
                'INGRESAR',
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => RegisterScreen(onNextClicked: () {}),
                  ),
                );
              },
              child: const Text("¿No tienes cuenta? - Regístrate"),
            ),
          ],
        ),
      ),
    );
  }
}
