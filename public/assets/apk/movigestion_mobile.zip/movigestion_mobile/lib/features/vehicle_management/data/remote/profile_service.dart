import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:movigestion_mobile/core/app_constants.dart';
import 'profile_model.dart';

class ProfileService {
  // Método para obtener el perfil por email y password
  Future<ProfileModel?> getProfileByEmailAndPassword(String email, String password) async {
    final url = Uri.parse('${AppConstants.baseUrl}${AppConstants.profile}/email/$email/password/$password');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        // Si la respuesta es exitosa (200 OK), parseamos el JSON y devolvemos el perfil
        return ProfileModel.fromJson(json.decode(response.body));
      } else {
        // Si la respuesta no es exitosa, imprimimos el error
        print('Failed to fetch profile. Status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        return null; // Retornamos null si el usuario o la contraseña no son correctos
      }
    } catch (e) {
      // Capturamos y mostramos cualquier error durante la solicitud
      print('Error al realizar la solicitud: $e');
      return null; // Retornamos null en caso de error
    }
  }
}
