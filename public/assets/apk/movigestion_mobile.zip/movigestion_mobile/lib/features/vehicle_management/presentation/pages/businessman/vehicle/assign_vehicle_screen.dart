import 'package:flutter/material.dart';

import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/profile/profile_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/shipments/shipments_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/vehicle/vehicles_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/reports/reports_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/login_screen.dart';



class AssignVehicleScreen extends StatefulWidget {
  final Function(Map<String, String>) onVehicleAdded;
  final String name;
  final String lastName;

  const AssignVehicleScreen({
    Key? key,
    required this.onVehicleAdded,
    required this.name,
    required this.lastName,
  }) : super(key: key);

  @override
  _AssignVehicleScreenState createState() => _AssignVehicleScreenState();
}

class _AssignVehicleScreenState extends State<AssignVehicleScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController modelController = TextEditingController();
  final TextEditingController plateController = TextEditingController();
  final TextEditingController assignedDriverController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C2F38),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () {
              Scaffold.of(context).openDrawer(); // Usa el context correcto para abrir el drawer
            },
          ),
        ),
      ),
      backgroundColor: const Color(0xFF2C2F38),

      // Aquí se define el sidebar (drawer)
      drawer: Drawer(
        backgroundColor: const Color(0xFF2C2F38), // Cambia el color de fondo del Drawer
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: const Color(0xFF2C2F38), // Cambia también el fondo del DrawerHeader si es necesario
              ),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/login_logo.png', // Reemplaza con la ruta correcta del logo
                    height: 100,
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.person, color: Colors.white), // Cambia el color de los íconos si es necesario
              title: Text('PERFIL', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfileScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );            },
            ),
            ListTile(
              leading: Icon(Icons.report, color: Colors.white),
              title: Text('REPORTES', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReportsScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.directions_car, color: Colors.white),
              title: Text('VEHICULOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VehiclesScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );             },
            ),
            ListTile(
              leading: Icon(Icons.local_shipping, color: Colors.white),
              title: Text('ENVIOS', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ShipmentsScreen(name: widget.name, lastName: widget.lastName),
                  ),
                );            },
            ),
            const SizedBox(height: 160),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.white),
              title: const Text('CERRAR SESIÓN', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginScreen(
                      onLoginClicked: (username, password) {
                        print('Usuario: $username, Contraseña: $password');
                      },
                      onRegisterClicked: () {
                        print('Registrarse');
                      },
                    ),
                  ),
                      (Route<dynamic> route) => false, // Cerrar todas las rutas anteriores y navegar solo a LoginScreen
                );
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Campo Modelo del Vehículo
              TextFormField(
                controller: modelController,
                decoration: const InputDecoration(labelText: 'Modelo del vehículo'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese el modelo';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              // Campo Placa del Vehículo
              TextFormField(
                controller: plateController,
                decoration: const InputDecoration(labelText: 'Placa del vehículo'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese la placa';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              // Campo Conductor Asignado
              TextFormField(
                controller: assignedDriverController,
                decoration: const InputDecoration(labelText: 'Conductor asignado'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese el nombre del conductor';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 40),
              // Botón Asignar Vehículo
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    // Crear el nuevo vehículo como un mapa
                    Map<String, String> newVehicle = {
                      'modelo': modelController.text,
                      'placa': plateController.text,
                      'asignado': assignedDriverController.text,
                    };
                    // Enviar el vehículo a VehiclesScreen
                    widget.onVehicleAdded(newVehicle);
                    Navigator.pop(context);  // Regresar a la pantalla anterior
                  }
                },
                child: const Text('Asignar Vehículo'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
