
import 'package:flutter/material.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/shipments/shipments_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/vehicle/vehicles_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/businessman/reports/reports_screen.dart';
import 'package:movigestion_mobile/features/vehicle_management/presentation/pages/login_register/login_screen.dart';


class ProfileScreen extends StatelessWidget {
  final String name;
  final String lastName;

  const ProfileScreen({
    Key? key,
    required this.name,
    required this.lastName,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C2F38),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.black),
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
      ),
      backgroundColor: const Color(0xFF2C2F38),
      drawer: Drawer(
        backgroundColor: const Color(0xFF2C2F38),
        child: Column(
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Color(0xFF2C2F38)),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/login_logo.png',
                    height: 100,
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: <Widget>[
                  ListTile(
                    leading: const Icon(Icons.person, color: Colors.white),
                    title: const Text('PERFIL', style: TextStyle(color: Colors.white)),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ProfileScreen(name: name, lastName: lastName)),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.report, color: Colors.white),
                    title: const Text('REPORTES', style: TextStyle(color: Colors.white)),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ReportsScreen(name: name, lastName: lastName),
                        ),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.directions_car, color: Colors.white),
                    title: const Text('VEHICULOS', style: TextStyle(color: Colors.white)),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => VehiclesScreen(name: name, lastName: lastName),
                        ),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.local_shipping, color: Colors.white),
                    title: const Text('ENVIOS', style: TextStyle(color: Colors.white)),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ShipmentsScreen(name: name, lastName: lastName),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 160),
                  ListTile(
                    leading: const Icon(Icons.logout, color: Colors.white),
                    title: const Text('CERRAR SESIÓN', style: TextStyle(color: Colors.white)),
                    onTap: () {
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                          builder: (context) => LoginScreen(
                            onLoginClicked: (username, password) {
                              print('Usuario: $username, Contraseña: $password');
                            },
                            onRegisterClicked: () {
                              print('Registrarse');
                            },
                          ),
                        ),
                            (Route<dynamic> route) => false, // Cerrar todas las rutas anteriores y navegar solo a LoginScreen
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),


      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const CircleAvatar(
              radius: 50,
              backgroundColor: Colors.black,
              child: Icon(
                Icons.person,
                color: Colors.white,
                size: 50,
              ),
            ),
            const SizedBox(height: 16),

            // Mostrar el mensaje de bienvenida
            Text(
              'Bienvenido $name $lastName',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
            const SizedBox(height: 20),

            // Texto Gerente/Transportista
            const Text(
              'Gerente',
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 20),

            // Formulario de nombre y DNI
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF2C2F38),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white),
              ),
              child: Column(
                children: [
                  TextField(
                    decoration: InputDecoration(
                      labelText: 'NOMBRE',
                      labelStyle: const TextStyle(color: Colors.white),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    decoration: InputDecoration(
                      labelText: 'DNI',
                      labelStyle: const TextStyle(color: Colors.white),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      // Lógica para actualizar los datos
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFFA000),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      minimumSize: const Size(double.infinity, 50),
                    ),
                    child: const Text(
                      'ACTUALIZAR DATOS',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            Image.asset(
              'assets/images/login_logo.png',
              height: 100,
            ),
          ],
        ),
      ),
    );
  }
}
