package com.example.movigestion_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
